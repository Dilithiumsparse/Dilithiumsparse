#ifndef CONFIG_H
#define CONFIG_H

#define DILITHIUM_MODE 2
// #define SIGN_STACKSTRATEGY 2

#endif
