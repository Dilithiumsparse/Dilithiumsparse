#ifndef CONFIG_H
#define CONFIG_H

#define DILITHIUM_MODE 5
// #define SIGN_STACKSTRATEGY 2

#endif
